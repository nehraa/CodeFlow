// Store exports
export { useBlueprintStore } from "./store/blueprint-store.js";
export type { BlueprintStore, FloatingGraphPanel, WorkbenchMode } from "./store/blueprint-store.js";

// Component exports
export { IdeLayout } from "./components/ide-layout.js";
export { FileTree } from "./components/file-tree.js";
export { FileTabs } from "./components/file-tabs.js";
export { GraphCanvas } from "./components/graph-canvas.js";
export { CodeEditor } from "./components/code-editor.js";
export { CodeDiffEditor } from "./components/code-diff-editor.js";
export { BlueprintWorkbench } from "./components/blueprint-workbench.js";
export { PolicyWorkbench } from "./components/policy-workbench.js";
export { IdeWorkbench } from "./components/ide-workbench.js";
export { OpencodeSettings } from "./components/opencode-settings.js";
export { prepareMonaco, toMonacoPath } from "./components/monaco-setup.js";
export { TypeScriptLanguageService, getTypeScriptLanguageService } from "./components/ts-language-service.js";

// Library exports
export { computeHeatmap, heatColor, heatGlow } from "./lib/heatmap.js";
export type { HeatmapData, HeatmapNodeMetric } from "./lib/heatmap.js";

export { applyTraceOverlay } from "./lib/traces.js";

export {
  getNavigationTarget,
  getNodesWithNavigation,
  formatNavigationTarget,
  hasNavigationMetadata,
  isValidNavigationTarget
} from "./lib/node-navigation.js";
export type { NavigationTarget } from "./lib/node-navigation.js";

export { addNodeToGraph, addEdgeToGraph, deleteNodeFromGraph } from "./lib/edit.js";

export {
  buildFlowNodes,
  buildFlowEdges,
  buildGhostFlowNodes,
  buildDetailFlow,
  indexRuntimeExecutionResult,
  buildExecutionProjection
} from "./lib/flow-view.js";
export type {
  NodeHealthState,
  FlowExecutionStatus,
  FlowExecutionState,
  FlowExecutionIndex,
  FlowExecutionProjection,
  FlowNodeData,
  InspectorSection,
  DetailFlowItem,
  DetailFlowGraph
} from "./lib/flow-view.js";